<header>
		<div class="container">
			<div id="branding">
				<h1 id="log"><span class="highlight">GAMMERS </span> SITE</h1>
				<hr>
			</div>
			<nav>
				<ul>
					<li class="current1"><a href="/">Home</a></li>
					<li class="current2"><a href="/about">About</a></li>
					<li class="current3"><a href="/services">Services</a></li>
					<li class="current4"><a href="/contact">Contact</a></li><hr>
					<br>
					<div id="drop-down" style="diplay:none">
					<li onclick="myFunction" class="current5"><a href="/login">Clients Login</a></li>
					<li class="current6"><a href="/admin">Staff Login</a></li>
					<li class="current7"><a href="/ADMIN">Admin</a></li>
					</div>
				</ul>
			</nav>
		</div>
	</header>