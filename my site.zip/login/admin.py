from django.contrib import admin

from login.models import accountInfomation, chatting

# Register your models here.
admin.site.register(accountInfomation)
admin.site.register(chatting)