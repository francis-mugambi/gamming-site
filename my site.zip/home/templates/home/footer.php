
<footer>
		<p>Desighned by GammingGroup ICTS, Copright &copy; 2022</p>
</footer>
